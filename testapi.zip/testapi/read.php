

<?php
/*READS DATA FROM DEPARTMENT TABLE*/

$conn=mysqli_connect("localhost","root","","test1");
if(!$conn)
	{
		die("unable to establish connection");
	}
	$query="select*from dept";
	$result=mysqli_query($conn,$query);
	while($row = mysqli_fetch_assoc($result))
	{
		$output[]=$row;
	}
	print(json_encode($output,JSON_PRETTY_PRINT));
	?>