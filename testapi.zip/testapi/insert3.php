
<html>
<link rel="stylesheet" href="style.css">
<form method="post" action="#">
<H3>INSERTS DATA INTO THE EMPLOYEE TABLE(EMP)</H3>
Enter EMPNO <input type="text" name="EMPNO"><BR><br>
Enter ENAME <input type="text" name="ENAME"><BR><br>
Enter JOB   <input type="text" name="JOB"><BR><br>
<input type="submit" name="insert"  value="click to insert">
</form>
</html>
<?php 
if(isset($_POST['insert']))
{
	$conn = mysqli_connect("localhost","root","","test1");
    
   $EMPNO= $_POST["EMPNO"];
    $ENAME = $_POST["ENAME"];
    $JOB= $_POST["JOB"];
    $query = "insert into  EMP(EMPNO,ENAME,JOB) values("."$EMPNO,'$ENAME','$JOB')";
    $result = $conn->query($query);
    if ($result == 1)
    {
        $data["message"] = "data saved successfully";
        $data["status"] = "Ok";
    }
    else
    {
        $data["message"] = "data not saved successfully";
        $data["status"] = "error";    
    }


    echo json_encode($data);
}
?>