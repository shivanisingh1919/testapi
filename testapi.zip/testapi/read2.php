<?php
/*READS DATA FROM STUDENT  TABLE*/
header("content-type:application/json");
$conn=mysqli_connect("localhost","root","","test1");
if(!$conn)
	{
		die("unable to establish connection");
	}
	$query="select*from student";
	$result=mysqli_query($conn,$query);
	while($row = mysqli_fetch_assoc($result))
	{
		$output[]=$row;
	}
	print(json_encode($output,JSON_PRETTY_PRINT));
	?>