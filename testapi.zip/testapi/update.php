<html>
<link rel="stylesheet" href="style.css">
<form method="post" action="#">
<H2> UPDATES DATA IN DEPARTMENT TABLE(DEPT)</H2>
Enter primary key of the row to update <input type="text" name="pk"><br><br>
<input type="submit" name="update"   value="click to update">
</form>
</html>
<?php 
if(isset($_POST['update']))
{
	$conn = mysqli_connect("localhost","root","","test1");
    
  
    $query = " update  DEPT SET DNAME='law' where DEPTNO=".$_POST['pk'];
    $result = $conn->query($query);
    if ((mysqli_affected_rows($conn))!=0)
    {
        $data["message"] = "data updated successfully ";
        $data["status"] = "Ok";
    }
    else
    {
        $data["message"] = "data not updated successfully please enter correct primary key";
        $data["status"] = "error";    
    }


    echo json_encode($data);
}
?>