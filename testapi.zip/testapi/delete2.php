<html>
<link rel="stylesheet" href="style.css">
<form method="post" action="#">
<H3>DELETES DATA FROM THE STUDENT  TABLE</H3>
Enter primary key of the row to delete <input type="text" name="pk"><br><br>
<input type="submit" name="delete"   value="click to delete">
</form>
</html>
<?php 
if(isset($_POST['delete']))
{
	$conn = mysqli_connect("localhost","root","","test1");
    
  
    $query = " delete from STUDENT where ID=".$_POST['pk'];
    $result = $conn->query($query);
        if ((mysqli_affected_rows($conn))!=0)
    {
        $data["message"] = "data deleted successfully";
        $data["status"] = "Ok";
    }
    else
    {
        $data["message"] = "data not deleted successfully enter the primary key that exists";
        $data["status"] = "error";    
    }


    echo json_encode($data);
}
?>