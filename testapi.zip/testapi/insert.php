<html>
<link rel="stylesheet" href="style.css">
<H2>INSERTS DATA INTO THE DEPARTMENT TABLE(DEPT)</H2>
<form method="post" ACTION="#">
Enter DEPTNO    <input type="text" name="DEPTNO"><BR><br>
Enter DNAME     <input type="text" name="DNAME"><BR><br>
Enter LOCATION  <input type="text" name="LOC"><BR><br>
<INPUT TYPE="SUBMIT" name="insert" value="Click to insert">
</form>
</html>
<?php 
if(isset($_POST['insert']))
{
	$conn = mysqli_connect("localhost","root","","test1");
    
   $DEPTNO = $_POST["DEPTNO"];
    $DNAME = $_POST["DNAME"];
    $LOC = $_POST["LOC"];
    $query = "insert into DEPT values("."$DEPTNO,'$DNAME','$LOC')";
    $result = $conn->query($query);
    if ($result == 1)
    {
        $data["message"] = "data saved successfully";
        $data["status"] = "Ok";
    }
    else
    {
        $data["message"] = "data not saved successfully";
        $data["status"] = "error";    
    }


    echo json_encode($data);
}
?>
























