<html>
<link rel="stylesheet" href="style.css">
<form method="post" action="#">
<H3> UPDATES DATA IN EMPLOYEE TABLE(EMP)</H3>
Enter primary key of the row to update <input type="text" name="pk"><br><br>
<input type="submit" name="update"   value="click to update">
</form>
</html>
<?php 
if(isset($_POST['update']))
{
	$conn = mysqli_connect("localhost","root","","test1");
    
  
    $query = " update  EMP SET ENAME='SHIVANI' where EMPNO=".$_POST['pk'];
    $result = $conn->query($query);
        if ((mysqli_affected_rows($conn))!=0)
    {
        $data["message"] = "data updated successfully";
        $data["status"] = "Ok";
    }
    else
    {
        $data["message"] = "data not updated successfully";
        $data["status"] = "error";    
    }


    echo json_encode($data);
}
?>