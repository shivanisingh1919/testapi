<?php
/*READS DATA FROM EMPLOYEE TABLE*/
header("content-type:application/json");
$conn=mysqli_connect("localhost","root","","test1");
if(!$conn)
	{
		die("unable to establish connection");
	}
	$query="select*from emp";
	$result=mysqli_query($conn,$query);
	while($row = mysqli_fetch_assoc($result))
	{
		$output[]=$row;
	}
	print(json_encode($output,JSON_PRETTY_PRINT));
	?>