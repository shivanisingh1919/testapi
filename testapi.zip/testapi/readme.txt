						TITLE:WEB APIs FOR CREATING,READING,DELETING AND UPDATING DATA OF A TABLE IN DATABASE
						
					A DATABASE NAMED test1 has already been created for this .It contains following tables:
					
				1.EMP
				2.DEPT
				3.STUDENT
  
  
  VERY IMPORTANT INSTRUCTIONS:

 1.Unzip the file named as testapi in wamp/www or wamp64/www or www/html(for xampp)
 2.Make changes in configuration in every page   according to hostname,username,password according to database to establish connection
 3.start localhost
 4.use phpmyadmin to create a new database and import test1.sql
 5.Open browser and run following files:

->For creating,reading,updating,deleting  data in DEPT table open insert.php,read.php,update.php,delete.php respectively.		
->For creating,reading,updating,deleting  data in EMP table open insert2.php,read2.php,update2.php,delete2.php respectively				
->For creating,reading,updating,deleting  data in STUDENT table open insert3.php,read3.php,update3.php,delete3.php respectively.