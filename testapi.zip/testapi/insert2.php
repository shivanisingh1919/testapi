<html>
<link rel="stylesheet" href="style.css">
<form method="post" action="#">
<H3>INSERTS DATA INTO THE  STUDENT TABLE</H3>
Enter ID   <input type="text" name="ID"><BR><br>
Enter NAME  <input type="text" name="NAME"><BR><br>
Enter MARKS <input type="text" name="MARKS"><BR><br>
<input type="submit" name="insert"  value="click to insert">
</form>
</html>
<?php 
if(isset($_POST['insert']))
{
	$conn = mysqli_connect("localhost","root","","test1");
    
   $ID = $_POST["ID"];
    $NAME = $_POST["NAME"];
    $MARKS= $_POST["MARKS"];
    $query = "insert into  student values("."$ID,'$NAME',$MARKS)";
    $result = $conn->query($query);
    if ($result == 1)
    {
        $data["message"] = "data saved successfully";
        $data["status"] = "Ok";
    }
    else
    {
        $data["message"] = "data not saved successfully";
        $data["status"] = "error";    
    }


    echo json_encode($data);
}
?>